# HAS-25-NOVORAPID - Guide d'implémentation du médicament v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HAS-25-NOVORAPID**

## Example Bundle: HAS-25-NOVORAPID



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "HAS-25-NOVORAPID",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-HAS-25-NOVORAPID",
      "meta" : {
        "profile" : ["https://hl7.fr/ig/fhir/medication/StructureDefinition/fr-medicationrequest"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-HAS-25-NOVORAPID\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-HAS-25-NOVORAPID</b></p><a name=\"medicationrequest-HAS-25-NOVORAPID\"> </a><a name=\"hcmedicationrequest-HAS-25-NOVORAPID\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medicationrequest.html\">FR Medication Request</a></p></div><p><b>R5: Full representation of the dosage instructions (new)</b>: </p><div><p>A administrer avant chaque repas en fonction de la glycémie 6 U si glycémie entre 1,5 et 2 g/L​ 8 U si glycémie entre 2 et 2,5 g/L 10 U si glycémie supérieure à 2,5 g/L</p>\n</div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400892402437}\">NOVORAPID FLEXPEN STYLO3ML</span></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2025-07-23 10:33:00+0100</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>note</b>: </p><blockquote><div><p>Prescription textuelle: NOVORAPID Flexpen® 100 UI / mL : A administrer avant chaque repas en fonction de la glycémie 6 U si glycémie entre 1,5 et 2 g/L​ 8 U si glycémie entre 2 et 2,5 g/L 10 U si glycémie supérieure à 2,5 g/L​</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>additionalInstruction</b>: <span title=\"Codes :\">Si glycémie entre 1,5 et 2 g/L</span></p><p><b>timing</b>: avant les repas, Une fois</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>6 U</td></tr></table></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>additionalInstruction</b>: <span title=\"Codes :\">Si glycémie entre 2 et 2,5 g/L</span></p><p><b>timing</b>: avant les repas, Une fois</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>8 U</td></tr></table></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>additionalInstruction</b>: <span title=\"Codes :\">Si glycémie supérieure à 2,5 g/L</span></p><p><b>timing</b>: avant les repas, Une fois</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>10 U</td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
        "valueMarkdown" : "A administrer avant chaque repas en fonction de la glycémie 6 U si glycémie entre 1,5 et 2 g/L​ 8 U si glycémie entre 2 et 2,5 g/L 10 U si glycémie supérieure à 2,5 g/L"
      }],
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
          "code" : "3400892402437",
          "display" : "NOVORAPID FLEXPEN STYLO3ML"
        }]
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2025-07-23T10:33:00+01:00",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "note" : [{
        "text" : "Prescription textuelle: NOVORAPID Flexpen® 100 UI / mL : A administrer avant chaque repas en fonction de la glycémie 6 U si glycémie entre 1,5 et 2 g/L​ 8 U si glycémie entre 2 et 2,5 g/L 10 U si glycémie supérieure à 2,5 g/L​"
      }],
      "dosageInstruction" : [{
        "additionalInstruction" : [{
          "text" : "Si glycémie entre 1,5 et 2 g/L"
        }],
        "timing" : {
          "repeat" : {
            "when" : ["AC"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 6,
            "unit" : "U"
          }
        }]
      },
      {
        "additionalInstruction" : [{
          "text" : "Si glycémie entre 2 et 2,5 g/L"
        }],
        "timing" : {
          "repeat" : {
            "when" : ["AC"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 8,
            "unit" : "U"
          }
        }]
      },
      {
        "additionalInstruction" : [{
          "text" : "Si glycémie supérieure à 2,5 g/L"
        }],
        "timing" : {
          "repeat" : {
            "when" : ["AC"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 10,
            "unit" : "U"
          }
        }]
      }]
    }
  }]
}

```
