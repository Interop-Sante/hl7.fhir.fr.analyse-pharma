# Presc-DIPROSONE-AppCut - Guide d'implémentation de l'analyse pharmaceutique v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Presc-DIPROSONE-AppCut**

## Example Bundle: Presc-DIPROSONE-AppCut



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Presc-DIPROSONE-AppCut",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "Medication",
      "id" : "medication-Presc-DIPROSONE-AppCut",
      "meta" : {
        "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-medication-noncompound"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-Presc-DIPROSONE-AppCut\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-Presc-DIPROSONE-AppCut</b></p><a name=\"medication-Presc-DIPROSONE-AppCut\"> </a><a name=\"hcmedication-Presc-DIPROSONE-AppCut\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400890277334}\">DIPROSONE® 0.05%, crème, tube 30 g</span></p><p><b>form</b>: <span title=\"Codes :{http://standardterms.edqm.eu 0071}\">crème</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>IsActive</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000091947}\">BETAMETHASONE</span></td><td>true</td><td>0.5 mg<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg = 'mg')</span>/ g<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMg = 'g')</span></td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
          "code" : "3400890277334",
          "display" : "DIPROSONE 0,05% CR TB30G"
        }],
        "text" : "DIPROSONE® 0.05%, crème, tube 30 g"
      },
      "form" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "0071",
          "display" : "crème"
        }],
        "text" : "crème"
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
            "code" : "100000091947",
            "display" : "bétaméthasone"
          }],
          "text" : "BETAMETHASONE"
        },
        "isActive" : true,
        "strength" : {
          "numerator" : {
            "value" : 0.5,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "unit" : "g",
            "system" : "http://unitsofmeasure.org",
            "code" : "g"
          }
        }
      }]
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-Presc-DIPROSONE-AppCut",
      "meta" : {
        "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-inpatient-medicationrequest"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-Presc-DIPROSONE-AppCut\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-DIPROSONE-AppCut</b></p><a name=\"medicationrequest-Presc-DIPROSONE-AppCut\"> </a><a name=\"hcmedicationrequest-Presc-DIPROSONE-AppCut\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <code>#medication-Presc-DIPROSONE-AppCut</code></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2021-07-29 13:04:23+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-14627</p><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: Une fois</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20003000}\">Voie cutanée</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{http://terminology.hl7.org/CodeSystem/dose-rate-type ordered}\">Ordered</span></td><td>1 application</td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationReference" : {
        "reference" : "#medication-Presc-DIPROSONE-AppCut"
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2021-07-29T13:04:23.435Z",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "groupIdentifier" : {
        "system" : "https://somehospital.fr/Prescrption-ID",
        "value" : "Presc-14627"
      },
      "dosageInstruction" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2021-07-29T13:04:00Z",
              "end" : "2021-08-03T13:03:59Z"
            },
            "timeOfDay" : ["08:00:00"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20003000",
            "display" : "Voie cutanée"
          }],
          "text" : "Voie cutanée"
        },
        "doseAndRate" : [{
          "type" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/dose-rate-type",
              "code" : "ordered",
              "display" : "Ordered"
            }],
            "text" : "Ordered"
          },
          "doseQuantity" : {
            "value" : 1,
            "unit" : "application"
          }
        }]
      }]
    }
  }]
}

```
