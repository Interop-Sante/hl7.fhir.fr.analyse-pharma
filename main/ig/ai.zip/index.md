# Accueil - Guide d'implémentation de l'analyse pharmaceutique v0.1.0-ballot

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://hl7.fr/ig/fhir/analyse-pharma/ImplementationGuide/hl7.fhir.fr.analyse-pharma | *Version*:0.1.0-ballot |
| Draft as of 2026-06-08 | *Computable Name*:APH |

### Introduction

>  **Attention !** Cet Implementation Guide n'est pas la version courante. La version courante sera accessible via l'URL canonique (https://hl7.fr/ig/fhir/analyse-pharma) lorsque celui-ci sera publié. 

Ce guide d’implémentation (IG) a pour vocation à spécifier les flux d’information autour de l’analyse pharmaceutique pour un patient dans un contexte hospitalier dans un premier temps.

1. [L’analyse pharmaceutique](analyse-Intro.md)

Ce domaine est pris en charge par le GT Pharmacie d’HL7 France au sein de l’association [Interop’Santé](https://www.interopsante.org/). L’historique des versions et des travaux est détaillé dans la page de [suivi des travaux](suivitravaux.md).

Cet IG est en développement continu. Certaines sections n’ont pas encore été complètement développées dans cette version. Ces sections sont néanmoins identifiées pour référence.

L’IG intègre également une partie indiquant [comment passer de flux PN13 à des ressources FHIR](transformation-PN13-vers-FHIR-AnalysePharma.md) et inversement.

#### Dépendances







#### Propriété intellectuelle

Certaines ressources sémantiques de ce guide sont protégées par des droits de propriété intellectuelle couverte par les déclarations ci-dessous. L’utilisation de ces ressources est soumise à l’acceptation et au respect des conditions précisées dans la licence d’utilisation de chacune d’entre elle.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.0.2/CodeSystem-ISO3166Part1.html): [APH](index.md), [FRInpatientPharmaceuticalAnalysisResultProfile](StructureDefinition-fr-inpatient-pharmaceutical-analysis-result.md)... Show 13 more, [FRInpatientPharmaceuticalInterventionSuggestionProfile](StructureDefinition-fr-inpatient-pharmaceutical-intervention-suggestion.md), [FrAnalysePharmaceutiqueLogical](StructureDefinition-fr-analyse-pharmaceutique-logical.md), [FrPN13FHIRPharmaceuticalAnalysisInterventionSansPropositionConceptMap](ConceptMap-PN13-FHIR-analpharm-interv-sans-prop-conceptmap.md), [FrPN13FHIRPharmaceuticalAnalysisValidationConceptMap](ConceptMap-PN13-FHIR-analpharm-val-conceptmap.md), [FrPharmaceuticalAnalysisPerformerTypeValueSet](ValueSet-fr-pharmaceutical-analysis-perfomer-type-value-set.md), [FrPharmaceuticalAnalysisResultCode](CodeSystem-fr-pharmaceutical-analysis-result-code.md), [FrPharmaceuticalAnalysisResultCodeValueSet](ValueSet-fr-pharmaceutical-analysis-result-code-value-set.md), [FrPharmaceuticalInterventionDevenirCode](CodeSystem-fr-pharmaceutical-intervention-devenir-code.md), [FrPharmaceuticalInterventionDevenirCodeValueSet](ValueSet-fr-pharmaceutical-intervention-devenir-code-value-set.md), [FrPharmaceuticalInterventionProblemCode](CodeSystem-fr-pharmaceutical-intervention-problem-code.md), [FrPharmaceuticalInterventionProblemCodeValueSet](ValueSet-fr-pharmaceutical-intervention-problem-code-value-set.md), [FrPharmaceuticalInterventionTypeCode](CodeSystem-fr-pharmaceutical-intervention-type-code.md) and [FrPharmaceuticalInterventionTypeCodeValueSet](ValueSet-fr-pharmaceutical-intervention-type-code-value-set.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://hl7.org/fhir/uv/xver-r5.r4/0.1.0/CodeSystem-v3-ucum.html): [Bundle/MultiLine-Presc-Sucralfate-Paracetamol](Bundle-MultiLine-Presc-Sucralfate-Paracetamol.md), [Medication/InLine-DOLIPRANE](Medication-InLine-DOLIPRANE.md)... Show 14 more, [Medication/InLine-med-EFFERALGAN](Medication-InLine-med-EFFERALGAN.md), [MedicationRequest/InLine-Analyse-Presc-CETAFEN-INJ](MedicationRequest-InLine-Analyse-Presc-CETAFEN-INJ.md), [MedicationRequest/InLine-Analyse-Presc-NEFOPAM](MedicationRequest-InLine-Analyse-Presc-NEFOPAM.md), [MedicationRequest/InLine-Analyse-Presc-Paracetamol](MedicationRequest-InLine-Analyse-Presc-Paracetamol.md), [MedicationRequest/InLine-Analyse-Presc-Paracetamol-Si-Douleur](MedicationRequest-InLine-Analyse-Presc-Paracetamol-Si-Douleur.md), [MedicationRequest/InLine-Inter-Arret-Paracetamol-Si-Douleur](MedicationRequest-InLine-Inter-Arret-Paracetamol-Si-Douleur.md), [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Intervention-Proposition](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Intervention-Proposition.md), [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Intervention-Substitution](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Intervention-Substitution.md), [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Presc-Paracetamol](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Presc-Paracetamol.md), [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Validation-Proposition](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Validation-Proposition.md), [MedicationRequest/InLine-presc-Paracetamol1](MedicationRequest-InLine-presc-Paracetamol1.md), [MedicationRequest/InLine-presc-Paracetamol2](MedicationRequest-InLine-presc-Paracetamol2.md), [Observation/InLine-Observation-poids-Avion](Observation-InLine-Observation-poids-Avion.md) and [Observation/InLine-observation-taille-Avion](Observation-InLine-observation-taille-Avion.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.0.2/CodeSystem-v3-loinc.html): [Observation/InLine-Observation-poids-Avion](Observation-InLine-Observation-poids-Avion.md) and [Observation/InLine-observation-taille-Avion](Observation-InLine-observation-taille-Avion.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [MedicationRequest/InLine-Analyse-Presc-Paracetamol-Si-Douleur](MedicationRequest-InLine-Analyse-Presc-Paracetamol-Si-Douleur.md), [MedicationRequest/InLine-Inter-Arret-Paracetamol-Si-Douleur](MedicationRequest-InLine-Inter-Arret-Paracetamol-Si-Douleur.md) and [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Presc-Paracetamol](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Presc-Paracetamol.md)


* Unless otherwise indicated, reproduction of material posted on Council of Europe websites, and reproduction of photographs for which the Council of Europe holds copyright – see legal notice \“photo credits\” – is authorised for private use and for informational and educational uses relating to the Council of Europe’s work. This authorisation is subject to the condition that the source be indicated and no charge made for reproduction. Persons wishing to make some other use than those specified above, including commercial use, of information and text posted on these sites are asked to apply for prior written authorisation to the Council of Europe, Directorate of Communication.

* [EDQM Standard Terms](http://tx.fhir.org/r4/ValueSet/edqm): [Bundle/MultiLine-Presc-METFORMINE-GLICLAZIDE](Bundle-MultiLine-Presc-METFORMINE-GLICLAZIDE.md), [Bundle/MultiLine-Presc-METHOTREXATE-LEDERFOLINE](Bundle-MultiLine-Presc-METHOTREXATE-LEDERFOLINE.md)... Show 37 more, [Bundle/MultiLine-Presc-Sucralfate-Paracetamol](Bundle-MultiLine-Presc-Sucralfate-Paracetamol.md), [Medication/InLine-DOLIPRANE](Medication-InLine-DOLIPRANE.md), [Medication/InLine-med-EFFERALGAN](Medication-InLine-med-EFFERALGAN.md), [MedicationRequest/InLine-Analyse-Presc-BINOCRIT](MedicationRequest-InLine-Analyse-Presc-BINOCRIT.md), [MedicationRequest/InLine-Analyse-Presc-CALCIDOSE](MedicationRequest-InLine-Analyse-Presc-CALCIDOSE.md), [MedicationRequest/InLine-Analyse-Presc-CELLUVISC](MedicationRequest-InLine-Analyse-Presc-CELLUVISC.md), [MedicationRequest/InLine-Analyse-Presc-CETAFEN-CPR](MedicationRequest-InLine-Analyse-Presc-CETAFEN-CPR.md), [MedicationRequest/InLine-Analyse-Presc-CETAFEN-INJ](MedicationRequest-InLine-Analyse-Presc-CETAFEN-INJ.md), [MedicationRequest/InLine-Analyse-Presc-COTAREG](MedicationRequest-InLine-Analyse-Presc-COTAREG.md), [MedicationRequest/InLine-Analyse-Presc-DOSTINEX](MedicationRequest-InLine-Analyse-Presc-DOSTINEX.md), [MedicationRequest/InLine-Analyse-Presc-Diazepam](MedicationRequest-InLine-Analyse-Presc-Diazepam.md), [MedicationRequest/InLine-Analyse-Presc-ELIQUIS-25](MedicationRequest-InLine-Analyse-Presc-ELIQUIS-25.md), [MedicationRequest/InLine-Analyse-Presc-ELIQUIS-50](MedicationRequest-InLine-Analyse-Presc-ELIQUIS-50.md), [MedicationRequest/InLine-Analyse-Presc-ESIDREX](MedicationRequest-InLine-Analyse-Presc-ESIDREX.md), [MedicationRequest/InLine-Analyse-Presc-ESOMEPRAZOLE](MedicationRequest-InLine-Analyse-Presc-ESOMEPRAZOLE.md), [MedicationRequest/InLine-Analyse-Presc-EZETIMIBE](MedicationRequest-InLine-Analyse-Presc-EZETIMIBE.md), [MedicationRequest/InLine-Analyse-Presc-INEGY](MedicationRequest-InLine-Analyse-Presc-INEGY.md), [MedicationRequest/InLine-Analyse-Presc-INNOHEP](MedicationRequest-InLine-Analyse-Presc-INNOHEP.md), [MedicationRequest/InLine-Analyse-Presc-LACRIFLUID](MedicationRequest-InLine-Analyse-Presc-LACRIFLUID.md), [MedicationRequest/InLine-Analyse-Presc-LANSOPRAZOLE](MedicationRequest-InLine-Analyse-Presc-LANSOPRAZOLE.md), [MedicationRequest/InLine-Analyse-Presc-LEVOTHYROX](MedicationRequest-InLine-Analyse-Presc-LEVOTHYROX.md), [MedicationRequest/InLine-Analyse-Presc-LOXAPAC](MedicationRequest-InLine-Analyse-Presc-LOXAPAC.md), [MedicationRequest/InLine-Analyse-Presc-MACROGOL](MedicationRequest-InLine-Analyse-Presc-MACROGOL.md), [MedicationRequest/InLine-Analyse-Presc-METFORMINE](MedicationRequest-InLine-Analyse-Presc-METFORMINE.md), [MedicationRequest/InLine-Analyse-Presc-Morphine](MedicationRequest-InLine-Analyse-Presc-Morphine.md), [MedicationRequest/InLine-Analyse-Presc-NEFOPAM](MedicationRequest-InLine-Analyse-Presc-NEFOPAM.md), [MedicationRequest/InLine-Analyse-Presc-Paracetamol](MedicationRequest-InLine-Analyse-Presc-Paracetamol.md), [MedicationRequest/InLine-Analyse-Presc-SIMVASTATINE](MedicationRequest-InLine-Analyse-Presc-SIMVASTATINE.md), [MedicationRequest/InLine-Analyse-Presc-TAREG](MedicationRequest-InLine-Analyse-Presc-TAREG.md), [MedicationRequest/InLine-Presc-EFFERALGAN](MedicationRequest-InLine-Presc-EFFERALGAN.md), [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Intervention-Proposition](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Intervention-Proposition.md), [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Intervention-Substitution](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Intervention-Substitution.md), [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Presc-Paracetamol](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Presc-Paracetamol.md), [MedicationRequest/InLine-Trad-PN13-FHIR-Analyse-Validation-Proposition](MedicationRequest-InLine-Trad-PN13-FHIR-Analyse-Validation-Proposition.md), [MedicationRequest/InLine-presc-EFFERALGAN2](MedicationRequest-InLine-presc-EFFERALGAN2.md), [MedicationRequest/InLine-presc-Paracetamol1](MedicationRequest-InLine-presc-Paracetamol1.md) and [MedicationRequest/InLine-presc-Paracetamol2](MedicationRequest-InLine-presc-Paracetamol2.md)


