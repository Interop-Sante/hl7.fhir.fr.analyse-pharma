# Presc-Nicotine-15mgPar16h - Guide d'implémentation de l'analyse pharmaceutique v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Presc-Nicotine-15mgPar16h**

## Example Bundle: Presc-Nicotine-15mgPar16h



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Presc-Nicotine-15mgPar16h",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "Medication",
      "id" : "medication-Presc-Nicotine-15mgPar16h",
      "meta" : {
        "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-medication-noncompound"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-Presc-Nicotine-15mgPar16h\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-Presc-Nicotine-15mgPar16h</b></p><a name=\"medication-Presc-Nicotine-15mgPar16h\"> </a><a name=\"hcmedication-Presc-Nicotine-15mgPar16h\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000079991}\">NICOTINE</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
          "code" : "100000079991",
          "display" : "nicotine"
        }],
        "text" : "NICOTINE"
      }
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-Presc-Nicotine-15mgPar16h",
      "meta" : {
        "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-inpatient-medicationrequest"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-Presc-Nicotine-15mgPar16h\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-Nicotine-15mgPar16h</b></p><a name=\"medicationrequest-Presc-Nicotine-15mgPar16h\"> </a><a name=\"hcmedicationrequest-Presc-Nicotine-15mgPar16h\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <code>#medication-Presc-Nicotine-15mgPar16h</code></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2021-07-19 18:33:41+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-14621</p><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: Durée 16?? , Une fois</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20070000}\">Voie transdermique</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>15 mg<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg = 'mg')</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationReference" : {
        "reference" : "#medication-Presc-Nicotine-15mgPar16h"
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2021-07-19T18:33:41.714Z",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "groupIdentifier" : {
        "system" : "https://somehospital.fr/Prescrption-ID",
        "value" : "Presc-14621"
      },
      "dosageInstruction" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2021-07-19T18:33:00Z",
              "end" : "2021-08-02T18:32:59Z"
            },
            "duration" : 16,
            "durationUnit" : "h",
            "timeOfDay" : ["07:00:00"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20070000",
            "display" : "Voie transdermique"
          }],
          "text" : "Voie transdermique"
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 15,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          }
        }]
      }]
    }
  }]
}

```
