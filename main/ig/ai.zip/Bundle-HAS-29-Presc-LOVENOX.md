# HAS-29-Presc-LOVENOX - Guide d'implémentation de l'analyse pharmaceutique v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HAS-29-Presc-LOVENOX**

## Example Bundle: HAS-29-Presc-LOVENOX



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "HAS-29-Presc-LOVENOX",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-HAS-29-Presc-LOVENOX",
      "meta" : {
        "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-medicationrequest"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-HAS-29-Presc-LOVENOX\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-HAS-29-Presc-LOVENOX</b></p><a name=\"medicationrequest-HAS-29-Presc-LOVENOX\"> </a><a name=\"hcmedicationrequest-HAS-29-Presc-LOVENOX\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medicationrequest.html\">FR Medication Request</a></p></div><p><b>R5: Full representation of the dosage instructions (new)</b>: </p><div><p>1 injection en SC par jour jusqu’à ce que l’INR de l'AVK soit dans la zone thérapeutique cible</p>\n</div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400892669465}\">LOVENOX 6000UI SRG0,6ML +ERIS</span></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2025-07-23 10:33:00+0100</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>note</b>: </p><blockquote><div><p>Prescription textuelle: ENOXAPARINE sodique 6000 UI (LOVENOX®), solution injectable en seringue préremplie : 1 injection en SC par jour jusqu’à ce que l’INR de l'AVK soit dans la zone thérapeutique cible.</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>additionalInstruction</b>: <span title=\"Codes :\">jusqu’à ce que l’INR de l'AVK soit dans la zone thérapeutique cible.</span></p><p><b>timing</b>: Une fois par 1 day</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20066000}\">Voie sous-cutanée</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 Seringue<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15052000 = 'Syringe')</span></td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
        "valueMarkdown" : "1 injection en SC par jour jusqu’à ce que l’INR de l'AVK soit dans la zone thérapeutique cible"
      }],
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
          "code" : "3400892669465",
          "display" : "LOVENOX 6000UI SRG0,6ML +ERIS"
        }]
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2025-07-23T10:33:00+01:00",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "note" : [{
        "text" : "Prescription textuelle: ENOXAPARINE sodique 6000 UI (LOVENOX®), solution injectable en seringue préremplie : 1 injection en SC par jour jusqu’à ce que l’INR de l'AVK soit dans la zone thérapeutique cible."
      }],
      "dosageInstruction" : [{
        "additionalInstruction" : [{
          "text" : "jusqu’à ce que l’INR de l'AVK soit dans la zone thérapeutique cible."
        }],
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "period" : 1,
            "periodUnit" : "d"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20066000",
            "display" : "Voie sous-cutanée"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "Seringue",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15052000"
          }
        }]
      }]
    }
  }]
}

```
