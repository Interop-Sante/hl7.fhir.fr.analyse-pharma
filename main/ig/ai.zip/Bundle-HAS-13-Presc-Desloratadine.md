# HAS-13-Presc-Desloratadine - Guide d'implémentation de l'analyse pharmaceutique v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HAS-13-Presc-Desloratadine**

## Example Bundle: HAS-13-Presc-Desloratadine



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "HAS-13-Presc-Desloratadine",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-HAS-13-Presc-Desloratadine",
      "meta" : {
        "profile" : ["https://hl7.fr/ig/fhir/analyse-pharma/StructureDefinition/fr-medicationrequest"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-HAS-13-Presc-Desloratadine\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-HAS-13-Presc-Desloratadine</b></p><a name=\"medicationrequest-HAS-13-Presc-Desloratadine\"> </a><a name=\"hcmedicationrequest-HAS-13-Presc-Desloratadine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medicationrequest.html\">FR Medication Request</a></p></div><p><b>R5: Full representation of the dosage instructions (new)</b>: </p><div><p>1 comprimé « 1 à  2 fois par jour » en fonction de la gêne allergique</p>\n</div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://BogusSystemMedicabase.com MV00000161}\">DESLORATADINE 5 mg comprimé</span></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2025-07-23 10:33:00+0100</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>note</b>: </p><blockquote><div><p>Prescription textuelle: DESLORATADINE 5 mg comprimé 1 comprimé « 1 à  2 fois par jour » en fonction de la gêne allergique</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>additionalInstruction</b>: <span title=\"Codes :\">en fonction de la gêne allergique</span></p><p><b>timing</b>: 1-2 par 1 day</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span></td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
        "valueMarkdown" : "1 comprimé « 1 à  2 fois par jour » en fonction de la gêne allergique"
      }],
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://BogusSystemMedicabase.com",
          "code" : "MV00000161",
          "display" : "DESLORATADINE 5 mg comprimé"
        }]
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2025-07-23T10:33:00+01:00",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "note" : [{
        "text" : "Prescription textuelle: DESLORATADINE 5 mg comprimé 1 comprimé « 1 à  2 fois par jour » en fonction de la gêne allergique"
      }],
      "dosageInstruction" : [{
        "additionalInstruction" : [{
          "text" : "en fonction de la gêne allergique"
        }],
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "frequencyMax" : 2,
            "period" : 1,
            "periodUnit" : "d"
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "comprimé",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          }
        }]
      }]
    }
  }]
}

```
